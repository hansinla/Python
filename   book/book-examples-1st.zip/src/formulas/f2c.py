F = 69.8
C = (5.0/9)*(F - 32)
print C

'''
Sample run:
unix/DOS> python f2c.py
21.0

This is correct because the inverse calculation is done by
unix/DOS> python c2f.py
69.8
'''
