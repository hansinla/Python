r = eval('1+2')
r
type(r)

r = 1+2
r
type(r)

r = eval('2.5')
r
type(r)

r = eval('"math programming"')
r
type(r)

r = eval('math programming')
r
type(r)

s = "'math programming'"
r = eval(s)
type(r)

r = eval('[1, 6, 7.5]')
r
type(r)
r = eval('(-1, 1)')
r
type(r)

from math import sqrt
r = eval('sqrt(2)')
r
type(r)
