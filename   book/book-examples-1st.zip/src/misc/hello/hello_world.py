print "Hello, World!"
