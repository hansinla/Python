a = 1
b = 10.0
c = a/b
if c == 0.1: print 'c == 0.1'
if c == 1/10.0: print 'c == 1/10.0'
if c == a/b: print 'c == a/b'
